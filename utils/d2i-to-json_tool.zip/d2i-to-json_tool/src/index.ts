
import { D2iLoader as D2iReader } from './types/D2iLoader';



export const D2iLoader = D2iReader

main()
async function main() {
  const d2iTest = new D2iLoader("./data/i18n_fr.d2i")
  const isLoaded = await d2iTest.loadFile()
  if (isLoaded) {
    let all: any = {}
    for (let i = 0; i < 1000000; i++) {
      if (d2iTest.hasD2i(i)) {
        const d2iRec = d2iTest.getD2i(i)
        if (d2iRec && d2iRec.id)
          all[d2iRec.id] = d2iRec
      }
    }
    const json: string = (JSON.stringify(all, undefined, 2))

    var fs = require('fs');
    fs.writeFile("json/i18n_fr.json", json, function (err: any) {
      if (err) {
        console.log(err);
      }
    });
  }
}
import { D2iRecord } from "./D2iRecord";

export type D2i = Map<number, D2iRecord>
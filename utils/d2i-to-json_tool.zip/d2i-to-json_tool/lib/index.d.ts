import { D2iLoader as D2iReader } from './types/D2iLoader';
export declare const D2iLoader: typeof D2iReader;

import { D2iRecord } from "./D2iRecord";
export declare type D2i = Map<number, D2iRecord>;

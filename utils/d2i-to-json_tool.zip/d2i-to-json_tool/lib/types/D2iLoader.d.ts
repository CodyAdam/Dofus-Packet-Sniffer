/// <reference types="node" />
import { D2i } from "./d2i";
import { D2iRecord } from './D2iRecord';
export declare class D2iLoader {
    filePath: string;
    fileBuffer: Buffer;
    filePointer: number;
    d2i: D2i;
    hasLoaded: boolean;
    sizeData: number;
    sizeIndex: number;
    isLoading: boolean;
    isD2iLoaded: boolean;
    constructor(filePath: string);
    loadFile(autoLoad?: boolean): Promise<boolean>;
    processd2i(): void;
    getD2i(id: number): undefined | D2iRecord;
    hasD2i(id: number): boolean;
    readBolean(): boolean;
    readInt(): number;
    readSize(position?: number | null): number;
    readString(size: number, position?: number | null): string;
    readD2iRecord(): void;
}

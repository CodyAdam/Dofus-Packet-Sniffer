export interface D2iRecord {
    id: number;
    value: string;
    hasDiacritical: boolean;
    valueDiacritical?: string;
}
